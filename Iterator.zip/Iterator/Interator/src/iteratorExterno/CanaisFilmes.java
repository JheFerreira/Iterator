/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iteratorExterno;

import java.util.ArrayList;

/**
 *
 * @author JéssicaFerreira
 */
public class CanaisFilmes implements AgregadoDeCanais {

    
        
        protected ArrayList<Canal> canais;

	public CanaisFilmes() {
		canais = new ArrayList<Canal>();
		canais.add(new Canal("O sexto sentido"));
		canais.add(new Canal("Efeito borboleta"));
		canais.add(new Canal("Uma linda mulher"));
		canais.add(new Canal("Viúva Negra"));
		canais.add(new Canal("Um amor para recordar"));
    }

    @Override
    public IteradorInterface criarIterator() {
        return new IteradorLIstaDeCanais(canais);
    }
    
}
