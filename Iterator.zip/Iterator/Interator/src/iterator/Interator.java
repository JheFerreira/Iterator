/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iterator;

/**
 *
 * @author JéssicaFerreira
 */
public class Interator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       CanaisEsportes meusCanais = new CanaisEsportes();
		System.out.println("Iterando com for:");
		for (IteratorCanais it = meusCanais.criarIterator(); !it.isDone(); it
				.proximoCanal()) {
			System.out.println(it.getNomeCanal());
		}

		System.out.println("\nIterando manualmente:");
		IteratorCanais it = meusCanais.criarIterator();
		System.out.println(it.getNomeCanal());
		it.proximoCanal();
		System.out.println(it.getNomeCanal());
		it.proximoCanal();
		System.out.println(it.getNomeCanal());
		it.proximoCanal();
		System.out.println(it.getNomeCanal());
		it.proximoCanal();
		System.out.println(it.getNomeCanal());

		System.out.println("\nIterando fora dos limites:");
		it.proximoCanal();
		System.out.println(it.getNomeCanal());
		it.first();
		it.voltarCanal();
		System.out.println(it.getNomeCanal());
	}
}
    

